if GetResourceState('es_extended') == 'started' then return end
if GetResourceState('qb-core') == 'started' then return end

function ShowNotification(text)
    SetNotificationTextEntry('STRING')
    AddTextComponentString(text)
    DrawNotification(false, false)
end

---@diagnostic disable: duplicate-set-field

-- =============================================
-- MARK: Variables
-- =============================================

Standalone = {}

Callbacks = {}

Callbacks.requests = {}
Callbacks.storage = {}
Callbacks.id = 0

-- =============================================
-- MARK: Internal Functions
-- =============================================

function Callbacks:Trigger(event, cb, invoker, ...)

    self.requests[self.id] = {
        await = type(cb) == "boolean",
        cb = cb or promise:new()
    }
    local table = self.requests[self.id]

    TriggerServerEvent("pickle_casinos:standalone:triggerServerCallback", event, self.id, invoker, ...)

    self.id += 1

    return table.cb
end

function Callbacks:Execute(cb, id, ...)
    local success, errorString = pcall(cb, ...)

    if not success then
        print(("[^1ERROR^7] Failed to execute Callback with RequestId: ^5%s^7"):format(id))
        error(errorString)
        return
    end
end

function Callbacks:ServerRecieve(requestId, invoker, ...)
    if not self.requests[requestId] then
        return error(("Server Callback with requestId ^5%s^1 Was Called by ^5%s^1 but does not exist."):format(requestId, invoker))
    end

    local callback = self.requests[requestId]

    self.requests[requestId] = nil

    if callback.await then
        callback.cb:resolve({...})
    else
        self:Execute(callback.cb, requestId, ...)
    end
end

function Callbacks:Register(name, resource, cb)
    self.storage[name] = {
        resource = resource,
        cb = cb
    }
end

function Callbacks:ClientRecieve(eventName, requestId, invoker, ...)

    if not self.storage[eventName] then
        return error(("Client Callback with requestId ^5%s^1 Was Called by ^5%s^1 but does not exist."):format(eventName, invoker))
    end

    local returnCb = function(...)
        TriggerServerEvent("pickle_casinos:standalone:clientCallback", requestId, invoker, ...)
    end
    local callback = self.storage[eventName].cb

    self:Execute(callback, requestId, returnCb, ...)
end

-- =============================================
-- MARK: Standalone Functions
-- =============================================

---@param eventName string
---@param callback function
---@param ... any
---@return nil
function Standalone.TriggerServerCallback(eventName, callback, ...)
    local invokingResource = GetInvokingResource()
    local invoker = (invokingResource and invokingResource ~= "unknown") and invokingResource or "es_extended"

    Callbacks:Trigger(eventName, callback, invoker, ...)
end

---@param eventName string
---@param ... any
---@return any
function Standalone.AwaitServerCallback(eventName, ...)
    local invokingResource = GetInvokingResource()
    local invoker = (invokingResource and invokingResource ~= "unknown") and invokingResource or "es_extended"

    local p = Callbacks:Trigger(eventName, false, invoker, ...)
    if not p then return end

    -- if the server callback takes longer than 15 seconds to respond, reject the promise
    SetTimeout(15000, function()
        if p.state == "pending" then
            p:reject("Server Callback Timed Out")
        end
    end)

    Citizen.Await(p)

    return table.unpack(p.value)
end

function Standalone.RegisterClientCallback(eventName, callback)
    local invokingResource = GetInvokingResource()
    local invoker = (invokingResource and invokingResource ~= "Unknown") and invokingResource or "es_extended"

    Callbacks:Register(eventName, invoker, callback)
end

---@param eventName string
---@return boolean
function Standalone.DoesClientCallbackExist(eventName)
    return Callbacks.storage[eventName] ~= nil
end

function Standalone.SecureNetEvent(event, handler)
    RegisterNetEvent(event, handler)
end

-- =============================================
-- MARK: Events
-- =============================================

Standalone.SecureNetEvent("pickle_casinos:standalone:triggerClientCallback", function(...)
    Callbacks:ClientRecieve(...)
end)

Standalone.SecureNetEvent("pickle_casinos:standalone:serverCallback", function(...)
    Callbacks:ServerRecieve(...)
end)

AddEventHandler("onResourceStop", function(resource)
    for k, v in pairs(Callbacks.storage) do
        if v.resource == resource then
            Callbacks.storage[k] = nil
        end
    end
end)

function ServerCallback(name, cb, ...)
    Standalone.TriggerServerCallback(name, cb, ...)
end

function CanAccessGroup(data)
    return false -- Not used in standalone
end 

function GetPlayersInArea(coords, radius)
    return {} -- Not used in standalone
end

function ResetClothes()
    return nil -- Not used in standalone
end

function Revive()
    return nil -- Not used in standalone
end

function Kill()
    SetEntityHealth(PlayerPedId(), 0)
end

RegisterNetEvent(GetCurrentResourceName()..":showNotification", function(text)
    ShowNotification(text)
end)

RegisterNetEvent('playerSpawned')
AddEventHandler('playerSpawned',function()
    if playerLoaded then return end
    playerLoaded = true
    TriggerServerEvent("pickle_casinos:initializePlayer")
end)

function ToggleOutfit(onduty)
    return nil -- Not used in standalone
end

-- Inventory Fallback

CreateThread(function()
    Wait(100)
    
    if InitializeInventory then return InitializeInventory() end -- Already loaded through inventory folder.

    Inventory = {}

    Inventory.Items = {}
    
    Inventory.Ready = false
    
    RegisterNetEvent("pickle_casinos:setupInventory", function(data)
        Inventory.Items = data.items
        Inventory.Ready = true
    end)
    
    RegisterNetEvent("pickle_casinos:updateInventory", function(inventory) 
        -- RefreshInventory(inventory)
    end)
end)