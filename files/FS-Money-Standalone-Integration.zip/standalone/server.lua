if GetResourceState('es_extended') == 'started' then return end
if GetResourceState('qb-core') == 'started' then return end

-- STANDALONE CALLBACKS

---@diagnostic disable: duplicate-set-field

-- =============================================
-- MARK: Variables
-- =============================================

Standalone = {}

Callbacks = {}

Callbacks.requests = {}
Callbacks.storage = {}
Callbacks.id = 0

-- =============================================
-- MARK: Internal Functions
-- =============================================

function Callbacks:Register(name, resource, cb)
    self.storage[name] = {
        resource = resource,
        cb = cb
    }
end

function Callbacks:Execute(cb, ...)
    local success, errorString = pcall(cb, ...)

    if not success then
        print(("[^1ERROR^7] Failed to execute Callback with RequestId: ^5%s^7"):format(self.currentId))
        error(errorString)
        return
    end
    self.currentId = nil
end

function Callbacks:Trigger(player, event, cb, invoker, ...)
    self.requests[self.id] = cb

    TriggerClientEvent("pickle_casinos:standalone:triggerClientCallback", player, event, self.id, invoker, ...)

    self.id += 1
end

function Callbacks:ServerRecieve(player, event, requestId, invoker, ...)
    self.currentId = requestId

    if not self.storage[event] then
        return error(("Server Callback with requestId ^5%s^1 Was Called by ^5%s^1 but does not exist."):format(event,
            invoker))
    end

    local returnCb = function(...)
        TriggerClientEvent("pickle_casinos:standalone:serverCallback", player, requestId, invoker, ...)
    end
    local callback = self.storage[event].cb

    self:Execute(callback, player, returnCb, ...)
end

function Callbacks:RecieveClient(requestId, invoker, ...)
    self.currentId = requestId

    if not self.requests[self.currentId] then
        return error(("Client Callback with requestId ^5%s^1 Was Called by ^5%s^1 but does not exist."):format(
            self.currentId, invoker))
    end

    local callback = self.requests[self.currentId]

    self:Execute(callback, ...)
    self.requests[requestId] = nil
end

---@param player number playerId
---@param eventName string
---@param callback function
---@param ... any
function Standalone.TriggerClientCallback(player, eventName, callback, ...)
    local invokingResource = GetInvokingResource()
    local invoker = (invokingResource and invokingResource ~= "Unknown") and invokingResource or "es_extended"

    Callbacks:Trigger(player, eventName, callback, invoker, ...)
end

---@param eventName string
---@param callback function
---@return nil
function Standalone.RegisterServerCallback(eventName, callback)
    local invokingResource = GetInvokingResource()
    local invoker = (invokingResource and invokingResource ~= "Unknown") and invokingResource or "es_extended"

    Callbacks:Register(eventName, invoker, callback)
end

---@param eventName string
---@return boolean
function Standalone.DoesServerCallbackExist(eventName)
    return Callbacks.storage[eventName] ~= nil
end

-- =============================================
-- MARK: Events
-- =============================================

RegisterNetEvent("pickle_casinos:standalone:clientCallback", function(requestId, invoker, ...)
    Callbacks:RecieveClient(requestId, invoker, ...)
end)

RegisterNetEvent("pickle_casinos:standalone:triggerServerCallback", function(eventName, requestId, invoker, ...)
    local source = source
    Callbacks:ServerRecieve(source, eventName, requestId, invoker, ...)
end)

AddEventHandler("onResourceStop", function(resource)
    for k, v in pairs(Callbacks.storage) do
        if v.resource == resource then
            Callbacks.storage[k] = nil
        end
    end
end)

function RegisterCallback(name, cb)
    Standalone.RegisterServerCallback(name, cb)
end

function RegisterUsableItem(...)
    -- NONE FOR STANDALONE
end

function ShowNotification(target, text)
    TriggerClientEvent(GetCurrentResourceName() .. ":showNotification", target, text)
end

function GetIdentifier(source)
    local identifiers = GetPlayerIdentifiers(source)
    for _, id in ipairs(identifiers) do
        if string.find(id, "license:") then
            return id -- returns something like "license:110000112345678"
        end
    end
    return identifiers[1]
end

function GetSourceFromIdentifier(identifier)
    for _, playerId in ipairs(GetPlayers()) do
        local playerIdentifier = GetIdentifier(playerId)
        if playerIdentifier == identifier then
            return playerId
        end
    end
    return nil
end

function GetPlayerCharacterName(source)
    return GetPlayerName(source)
end

function CanAccessGroup(source, data)
    return false -- Not used in standalone
end

function CheckPermission(source, permission)
    return false -- Not used in standalone
end

function AddMoney(source, count, currency)
    local currency = currency or "money"
    if (currency == "money") then
        exports['FS-Money']:addMoney('cash', source, count, 'Pickle\'s Casino')
    elseif (currency == "dirty") then
        exports['FS-Money']:addMoney('dirty', source, count, 'Pickle\'s Casino')
    end
    TriggerClientEvent("pickle_casinos:updateMoney", source, GetMoney(source, currency))
end

function RemoveMoney(source, count, currency)
    local currency = currency or "money"
    if (currency == "money") then
        exports['FS-Money']:removeMoney('cash', source, count, 'Pickle\'s Casino')
    elseif (currency == "dirty") then
        exports['FS-Money']:removeMoney('dirty', source, count, 'Pickle\'s Casino')
    end
    TriggerClientEvent("pickle_casinos:updateMoney", source, GetMoney(source, currency))
end

function GetMoney(source, currency)
    local currency = currency or "money"
    local money = 0
    if (currency == "money") then
        money = exports['FS-Money']:getMoney('cash', source)
    elseif (currency == "dirty") then
        money = exports['FS-Money']:getMoney('dirty', source)
    end
    return money
end

function GetOwnedVehicleFromPlate(plate)
    return nil -- Not used in standalone
end

function AddOwnedVehicle(source, plate, model)
    return nil -- Not used in standalone
end

function UpdateVehiclePlate(source, plate, newPlate)
    return nil -- Not used in standalone
end

function GetPlayerJob(source)
    return nil -- Not used in standalone
end

function SetPlayerJob(source, job, grade)
    return nil -- Not used in standalone
end

function IsPlayerAdmin(source)
    for i = 1, #Config.AdminGroups do
        if IsPlayerAceAllowed(source, Config.AdminGroups[i]) then
            return true
        end
    end
    return false
end

function AddSocietyMoney(name, amount)
    return nil -- Not used in standalone
end

function AddOwnedVehicle(source, model)
    return nil -- Not used in standalone
end

-- Inventory Fallback

CreateThread(function()
    Wait(100)

    if InitializeInventory then return InitializeInventory() end -- Already loaded through inventory folder.

    Inventory = {}

    Inventory.Items = {}

    Inventory.Ready = false

    Inventory.CanCarryItem = function(source, name, count)
        return true
    end

    Inventory.GetInventory = function(source)
        return {}
    end

    Inventory.UpdateInventory = function(source)
        SetTimeout(1000, function()
            TriggerClientEvent("pickle_casinos:updateInventory", source, Inventory.GetInventory(source))
        end)
    end

    Inventory.AddItem = function(source, name, count, metadata) -- Metadata is not required.
        if name == "pokerchips" then
            exports['FS-Money']:addMoney('pokerchips', source, count, 'Pickle\'s Casino', false)
        elseif name == "cash" then
            exports['FS-Money']:addMoney('cash', source, count, 'Pickle\'s Casino', false)
        end
    end

    Inventory.RemoveItem = function(source, name, count)
        if name == "pokerchips" then
            exports['FS-Money']:removeMoney('pokerchips', source, count, 'Pickle\'s Casino', false)
        elseif name == "cash" then
            exports['FS-Money']:removeMoney('cash', source, count, 'Pickle\'s Casino', false)
        end
        Inventory.UpdateInventory(source)
    end

    Inventory.AddWeapon = function(source, name, count, metadata) -- Metadata is not required.
        return nil                                                -- Not used in standalone
        --Inventory.UpdateInventory(source)
    end

    Inventory.RemoveWeapon = function(source, name, count)
        return nil -- Not used in standalone
        --Inventory.UpdateInventory(source)
    end

    Inventory.GetItemCount = function(source, name)
        if name == "pokerchips" then
            return exports['FS-Money']:getMoney('pokerchips', source)
        elseif name == "cash" then
            return exports['FS-Money']:getMoney('cash', source)
        end
        return 0
    end

    Inventory.HasWeapon = function(source, name, count)
        return false -- Not used in standalone
    end

    RegisterCallback("pickle_casinos:getInventory", function(source, cb)
        cb(Inventory.GetInventory(source))
    end)

    Inventory.Items = {
        ["pokerchips"] = { label = "Poker Chips" }
    }
    Inventory.Ready = true
end)
